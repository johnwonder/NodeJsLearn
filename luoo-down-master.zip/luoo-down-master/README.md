luoo-down
=========

luoo-down is a [luoo.net-落网](http://www.luoo.net/) music downloader based on nodejs.

This is a simple of fetching <http://www.luoo.net/music/613>

![luoo-down](http://stanzhai.github.io/images/project/luoo-down.png)

## How to use

1. Use git clone this code `git clone https://github.com/stanzhai/luoo-down.git`
2. Run `npm install` then run luoo-down by command `node app`
3. Select the music you want to download then press ENTER.
4. After the music has been downloaded, press ENTER open the music in you preferred application !
5. The downloaded music path is `downloads`, under this folder you will see:
  ![download path](http://stanzhai.github.io/images/project/luoo-down-path.png)

## License

The MIT License (MIT)
